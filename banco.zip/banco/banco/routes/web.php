<?php

use Illuminate\Support\Facades\Route;
use App\Models\User; // Adicione a importação do modelo User
use Illuminate\Http\Request; // Adicione a importação do Request
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\CadastroController;
use App\Http\Controllers\LoginController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\LogoutController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function () {
    return view('login');
});

Route::post('/login', function (Request $request) {
    // Lógica de autenticação aqui
});

Route::get('/cadastro', function () {
    return view('cadastro');
});

Route::post('/cadastro', [CadastroController::class, 'store']);

Route::get('/dashboard', function () {
    return view('dashboard');
});
Route::get('/login', [LoginController::class, 'showLoginForm']);
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', function () {
    Auth::logout();
    return redirect('/');
});
Route::post('/logout', [LogoutController::class, 'logout']);
