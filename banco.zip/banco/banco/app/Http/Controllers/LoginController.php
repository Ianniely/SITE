<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('login'); // Retorna a view do formulário de login
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            // O usuário está autenticado
            return redirect('/dashboard')->with('message', 'Bem-vindo, ' . Auth::user()->name . '!');
        }

        // O usuário não está autenticado
        return redirect('/login')->with('error', 'Credenciais inválidas. Por favor, tente novamente.');
    }
}
