<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

use Illuminate\Support\Facades\Hash;

class CadastroController extends Controller
{
    public function store(Request $request)
    {
        $email = $request->input('email');
    
        // Verifica se o e-mail já está cadastrado
        $userExists = User::where('email', $email)->exists();
    
        if($userExists) {
            return redirect('/cadastro')->with('error', 'Este e-mail já está cadastrado. Por favor, escolha outro.');
        }
    
        $name = $request->input('name');
        $password = Hash::make($request->input('password'));
    
        $user = new User;
        $user->name = $name;
        $user->email = $email;
        $user->password = $password;
    
        $user->save();
    
        return redirect('/login')->with('message', 'Cadastro realizado, realize seu login.');
    }
}
