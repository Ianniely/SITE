<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        /* Estilo para o corpo da página */
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background-color: #f8bbd0; /* Rosa claro */
    font-family: Arial, sans-serif;
    color: white;
}

/* Estilo para o conteúdo do dashboard */
.dashboard-content {
    background-color: #8e24aa; /* Purple */
    max-width: 300px;
    margin: 0 auto;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Estilo para o texto de boas-vindas */
.dashboard-welcome {
    font-size: 24px;
    margin-bottom: 20px;
}

/* Estilo para o botão de logout */
.logout-button {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 4px;
    background-color: #f8bbd0; /* Rosa claro */
    cursor: pointer;
    font-size: 16px;
}


    </style>
</head>
<body>
    <div>
    <h1>Dashboard</h1>
  
    @if(session('message'))
        <p>{{ session('message') }}</p>
    @endif
  
        <form action="{{ url('/logout') }}" method="post">
            @csrf
            <button type="submit" class="logout-button">Logout</button>
</div>
</body>
</html>
