<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
  /* Estilo para o corpo da página */
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background-color: #f8bbd0; /* Rosa claro */
    font-family: Arial, sans-serif;
    color:white;
}

/* Estilo para o formulário */
form {
    background-color: #8e24aa; /* Purple */
    max-width: 300px;
    margin: 0 auto;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Estilo para os campos de entrada e botão */
input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: none;
    border-radius: 4px;
    box-sizing: border-box;
}

button {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 4px;
    background-color: #f8bbd0; 
}


    </style>
</head>
<body>
    <div>
    <form action="<?php echo e(url('/login')); ?>" method="post">

    <?php echo csrf_field(); ?>

    <h1>login</h1>
    

    <input type="text"placeholder="name"name="name">
    <input type="text"placeholder="email"name="email">
    <input type="text"placeholder="senha"name="password">
    <button>next</button>
    </form>

    <?php if(session('error')): ?>
        <p><?php echo e(session('error')); ?></p>
    <?php endif; ?>
</div>
</body>
</html><?php /**PATH C:\Users\is693\banco\banco\resources\views/login.blade.php ENDPATH**/ ?>