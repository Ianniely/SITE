<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login e Cadastro</title>
  
    <style>
        body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background-color: #f8bbd0; /* Rosa claro */
    color:white;
}

.container {
    display: flex;
    justify-content: space-around;
    max-width: 600px;
    width: 100%;
}

.option {
    background-color: #8e24aa; /* Purple */
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    text-align: center;
    color: #fff;
    text-decoration: none;
}

.option h2 {
    font-size: 24px;
    
}

.option p {
    font-size: 14px;
}

.option a {
    display: block;
    margin-top: 10px;
    padding: 15px 20px;
    border-radius: 4px;
    background-color: #f8bbd0; /* Rosa claro */
    color: #8e24aa; /* Purple */
    text-decoration: none;
    font-size: 16px;
    font-weight: bold;
   
}

.option a:hover {
    background-color: #ff80ab; /* Rosa claro mais claro */
}
h1{
    margin-left:70px;
}
div{
    margin-left:25px;
    margin-right:10px;
    
}




    </style>
</head>
<body>
   <div>
   <h1>BEM VINDO AO NOSSO SITE</h1>
    <h1>REALIZE SUA AUTENTICAÇÃO</h1>
    <div class="container">
        <div class="option">
            <h2>Entrar</h2>
            <p>Já tem uma conta? Faça o login abaixo.</p>
            <a href="{{url('/login')}}">Login</a>
        </div>

        <div class="option">
            <h2>Cadastrar-se</h2>
            <p>Ainda não tem uma conta? Cadastre-se agora.</p>
            <a href="{{url('/cadastro')}}">Cadastro</a>
        </div>
    </div>
</div>
</body>
</html> 
